module.exports = (sock, buyModule) => {
  sock.ev.on("messages.upsert", async (m) => {
    try {
      const msg = m.messages?.[0]
      if (!msg?.message) return

      const mmsg = msg.message

      let buy_text = ""

      if (mmsg?.buttonsResponseMessage?.selectedButtonId) {
        buy_text = mmsg.buttonsResponseMessage.selectedButtonId
      }

      if (!buy_text) return

      if (!buy_text.startsWith("BUY_LIMIT_")) return

      const amount = parseInt(buy_text.split("_")[2])

      const from = msg.key.remoteJid

      await buyModule.runBuyCommand({
        from,
        args: [".buy", "limit", amount],
        msg,
        sock
      })

    } catch (e) {
      console.log("BUY LISTENER ERROR:", e)
    }
  })
}